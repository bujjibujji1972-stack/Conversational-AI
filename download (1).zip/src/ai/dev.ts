import { config } from 'dotenv';
config();

import '@/ai/flows/generate-creative-text.ts';
import '@/ai/flows/chat-with-assistant.ts';
import '@/ai/flows/summarize-web-content.ts';
import '@/ai/flows/text-to-speech.ts';
import '@/ai/flows/visual-question-answer.ts';
