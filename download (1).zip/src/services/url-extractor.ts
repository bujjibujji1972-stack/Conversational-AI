'use server';

// This is a placeholder for a real web content extractor.
// In a real application, you would use a library like Cheerio or a headless browser
// to fetch the URL and extract the main content.
export async function extractContent(url: string): Promise<string> {
  console.log(`Extracting content from: ${url}`);
  try {
    const response = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, next: { revalidate: 3600 } });
    if (!response.ok) {
      throw new Error(`Could not fetch the URL. Status: ${response.status}`);
    }
    
    // A more robust implementation would parse the HTML and extract the main article body.
    // For this example, we will naively strip HTML tags from the first 5000 characters.
    const html = await response.text();
    return html
      .replace(/<style[^>]*>.*<\/style>/gs, ' ')
      .replace(/<script[^>]*>.*<\/script>/gs, ' ')
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s\s+/g, ' ')
      .trim()
      .substring(0, 5000);
  } catch (error) {
    console.error('Error extracting content:', error);
    if (error instanceof Error) {
        return `Error: ${error.message}`;
    }
    return 'Error: Could not extract content from the URL.';
  }
}
