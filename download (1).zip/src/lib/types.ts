export interface Task {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
}

export interface Reminder {
  id: string;
  text: string;
  remindAt: string;
  completed: boolean;
}
