
"use client";

import {
  Sidebar,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from '@/components/ui/sidebar';
import {
  MessageSquare,
  Link as LinkIcon,
  Sparkles,
  ListChecks,
  Bot,
  Mic,
  Search,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ThemeToggle } from './theme-toggle';

const menuItems = [
  { href: '/chat', label: 'Chat', icon: MessageSquare },
  { href: '/voice-assistant', label: 'Voice Assistant', icon: Mic },
  { href: '/summarize', label: 'Summarize', icon: LinkIcon },
  { href: '/create', label: 'Create', icon: Sparkles },
  { href: '/tasks', label: 'Tasks & Reminders', icon: ListChecks },
  { href: '/analysis', label: 'Analysis', icon: Search },
  { href: '/search', label: 'Google Search', icon: Search },
];

export function AppSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2 p-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Bot className="h-5 w-5" />
          </div>
          <span className="text-lg font-semibold text-sidebar-foreground">
            AssistAI
          </span>
        </div>
      </SidebarHeader>
      <SidebarMenu>
        {menuItems.map((item) => (
          <SidebarMenuItem key={item.href}>
            <SidebarMenuButton
              as={Link}
              href={item.href}
              isActive={pathname === item.href}
              tooltip={{ children: item.label }}
            >
              <item.icon />
              <span>{item.label}</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
      <SidebarFooter>
        <ThemeToggle />
      </SidebarFooter>
    </Sidebar>
  );
}
