
"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { summarizeWebContent } from '@/ai/flows/summarize-web-content';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  url: z.string().url({ message: 'Please enter a valid URL.' }),
});

export default function SummarizePage() {
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      url: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setSummary('');
    try {
      const result = await summarizeWebContent({ url: values.url });
      if (result.summary.startsWith('Error:')) {
        toast({
          variant: "destructive",
          title: "Summarization Failed",
          description: result.summary,
        });
      } else {
        setSummary(result.summary);
      }
    } catch (error) {
      console.error('Error summarizing content:', error);
      toast({
        variant: "destructive",
        title: "An unexpected error occurred",
        description: "Failed to summarize the web content. Please check the console for details.",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex flex-col h-full">
       <header className="p-4 border-b">
        <h1 className="text-2xl font-bold">Web Content Summarizer</h1>
      </header>
      <div className="flex-1 p-4 md:p-6 grid md:grid-cols-2 gap-6 overflow-auto">
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Summarize a Web Page</CardTitle>
            <CardDescription>
              Enter a URL below to get a concise summary of its content.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isLoading} className="w-full">
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isLoading ? 'Summarizing...' : 'Summarize'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Summary</CardTitle>
            <CardDescription>The generated summary will appear here.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex">
            <ScrollArea className="flex-1 w-full">
              {isLoading && !summary && (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              )}
              {summary && (
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <p>{summary}</p>
                </div>
              )}
              {!isLoading && !summary && (
                  <div className="flex items-center justify-center h-full text-muted-foreground text-center p-4">
                      <p>Your summary will be displayed here once generated.</p>
                  </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
