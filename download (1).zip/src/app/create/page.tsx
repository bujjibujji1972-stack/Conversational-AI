
"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { generateCreativeText } from '@/ai/flows/generate-creative-text';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  prompt: z.string().min(10, {
    message: 'Prompt must be at least 10 characters long.',
  }),
});

export default function CreatePage() {
  const [creativeText, setCreativeText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      prompt: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setCreativeText('');
    try {
      const result = await generateCreativeText({ prompt: values.prompt });
      setCreativeText(result.creativeText);
    } catch (error) {
      console.error('Error generating creative text:', error);
      toast({
        variant: 'destructive',
        title: 'An unexpected error occurred',
        description: 'Failed to generate creative text. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex flex-col h-full">
      <header className="p-4 border-b">
        <h1 className="text-2xl font-bold">Creative Text Generator</h1>
      </header>
      <div className="flex-1 p-4 md:p-6 grid md:grid-cols-2 gap-6 overflow-auto">
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Unleash Your Creativity</CardTitle>
            <CardDescription>
              Provide a prompt and let the AI write a short story, poem, or
              any other creative piece for you.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="prompt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Prompt</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="e.g., A detective who can talk to cats solves a mystery in a futuristic city..."
                          className="resize-none min-h-[150px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isLoading} className="w-full">
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isLoading ? 'Generating...' : 'Generate Text'}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Generated Text</CardTitle>
            <CardDescription>The AI's creation will appear below.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex">
            <ScrollArea className="w-full h-full">
              {isLoading && (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              )}
              {creativeText && (
                <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                  {creativeText}
                </div>
              )}
              {!isLoading && !creativeText && (
                <div className="flex items-center justify-center h-full text-center text-muted-foreground p-4">
                  <div>
                    <Sparkles className="mx-auto h-12 w-12" />
                    <p className="mt-4">The magic happens here. Give me a prompt to get started!</p>
                  </div>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
