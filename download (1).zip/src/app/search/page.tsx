
"use client";

import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search as SearchIcon } from 'lucide-react';

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [embedUrl, setEmbedUrl] = useState('https://www.google.com/search?igu=1&q=studio.dev');

  const handleSearchQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setEmbedUrl(`https://www.google.com/search?igu=1&q=${encodeURIComponent(searchQuery)}`);
    }
  }

  return (
    <div className="flex flex-col h-full">
      <header className="p-4 border-b">
        <h1 className="text-2xl font-bold flex items-center gap-2"><SearchIcon /> Google Search</h1>
      </header>
      <main className="flex-1 flex flex-col p-4 md:p-6 gap-4">
        <div className="flex flex-col md:flex-row gap-2">
            <Input 
                placeholder="Enter search query..."
                value={searchQuery}
                onChange={handleSearchQueryChange}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch}><SearchIcon className="mr-2 h-4 w-4"/> Search</Button>
        </div>
        <div className="flex-1 border rounded-lg overflow-hidden">
            <iframe
            className="w-full h-full"
            src={embedUrl}
            title="Google Search"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
            ></iframe>
        </div>
      </main>
    </div>
  );
}
