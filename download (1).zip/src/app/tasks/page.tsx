
"use client";

import { useState, useEffect, useRef } from 'react';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { useToast } from '@/hooks/use-toast';
import type { Task, Reminder } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Trash2, Calendar as CalendarIcon, Bell, Plus, X } from 'lucide-react';
import { format, parseISO } from 'date-fns';

export default function TasksPage() {
  const [tasks, setTasks] = useLocalStorage<Task[]>('tasks', []);
  const [reminders, setReminders] = useLocalStorage<Reminder[]>('reminders', []);
  const [newTask, setNewTask] = useState('');
  const [newReminderText, setNewReminderText] = useState('');
  const [newReminderDate, setNewReminderDate] = useState<Date | undefined>(new Date());
  const { toast } = useToast();

  // Use refs to store functions that don't need to be in the useEffect dependency array
  const toastRef = useRef(toast);
  const setRemindersRef = useRef(setReminders);
  
  useEffect(() => {
    toastRef.current = toast;
    setRemindersRef.current = setReminders;
  });


  useEffect(() => {
    const interval = setInterval(() => {
      // Use the ref to the setter function
      setRemindersRef.current(prevReminders => {
        const now = new Date();
        let madeChanges = false;
        const updatedReminders = prevReminders.map(r => {
          if (!r.completed && new Date(r.remindAt) <= now) {
            // Use the ref to the toast function
            toastRef.current({
              title: "Reminder!",
              description: r.text,
            });
            madeChanges = true;
            return { ...r, completed: true };
          }
          return r;
        });
        
        if (madeChanges) {
          return updatedReminders;
        }
        return prevReminders;
      });
    }, 1000 * 5); // Check every 5 seconds
    
    return () => clearInterval(interval);
  }, []); // Empty dependency array ensures this runs only once on mount

  const handleAddTask = () => {
    if (newTask.trim() === '') return;
    const task: Task = {
      id: Date.now().toString(),
      text: newTask,
      completed: false,
      createdAt: new Date().toISOString(),
    };
    setTasks([task, ...tasks]);
    setNewTask('');
  };

  const handleToggleTask = (id: string) => {
    setTasks(tasks.map(t => (t.id === id ? { ...t, completed: !t.completed } : t)));
  };

  const handleDeleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const handleAddReminder = () => {
    if (newReminderText.trim() === '' || !newReminderDate) return;
    const reminder: Reminder = {
      id: Date.now().toString(),
      text: newReminderText,
      remindAt: newReminderDate.toISOString(),
      completed: false,
    };
    setReminders([reminder, ...reminders].sort((a,b) => new Date(a.remindAt).getTime() - new Date(b.remindAt).getTime()));
    setNewReminderText('');
    setNewReminderDate(new Date());
  };

  const handleDeleteReminder = (id: string) => {
    setReminders(reminders.filter(r => r.id !== id));
  };

  const pendingTasks = tasks.filter(t => !t.completed);
  const completedTasks = tasks.filter(t => t.completed);

  return (
    <div className="flex flex-col h-full">
      <header className="p-4 border-b">
        <h1 className="text-2xl font-bold">Tasks & Reminders</h1>
      </header>
      <main className="flex-1 p-4 md:p-6 overflow-hidden">
        <Tabs defaultValue="tasks" className="h-full flex flex-col">
          <TabsList className="w-full md:w-auto self-start">
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="reminders">Reminders</TabsTrigger>
          </TabsList>
          
          <TabsContent value="tasks" className="flex-1 overflow-auto mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Manage Your Tasks</CardTitle>
                <div className="flex space-x-2 pt-2">
                  <Input value={newTask} onChange={(e) => setNewTask(e.target.value)} placeholder="Add a new task..." onKeyDown={(e) => e.key === 'Enter' && handleAddTask()} />
                  <Button onClick={handleAddTask}><Plus className="mr-2 h-4 w-4" /> Add Task</Button>
                </div>
              </CardHeader>
              <CardContent>
                <h3 className="font-semibold text-lg mb-2">Pending ({pendingTasks.length})</h3>
                <div className="space-y-2 mb-6">
                  {pendingTasks.map(task => (
                    <div key={task.id} className="flex items-center gap-2 rounded-md p-2 bg-background hover:bg-muted/50 transition-colors">
                      <Checkbox id={`task-${task.id}`} checked={task.completed} onCheckedChange={() => handleToggleTask(task.id)} />
                      <label htmlFor={`task-${task.id}`} className="flex-1 text-sm">{task.text}</label>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteTask(task.id)}><Trash2 className="h-4 w-4 text-muted-foreground" /></Button>
                    </div>
                  ))}
                   {pendingTasks.length === 0 && <p className="text-sm text-muted-foreground p-2">No pending tasks. Great job!</p>}
                </div>
                <h3 className="font-semibold text-lg mb-2">Completed ({completedTasks.length})</h3>
                <div className="space-y-2">
                  {completedTasks.map(task => (
                    <div key={task.id} className="flex items-center gap-2 rounded-md p-2 bg-background hover:bg-muted/50 transition-colors">
                      <Checkbox id={`task-${task.id}`} checked={task.completed} onCheckedChange={() => handleToggleTask(task.id)} />
                      <label htmlFor={`task-${task.id}`} className="flex-1 text-sm line-through text-muted-foreground">{task.text}</label>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteTask(task.id)}><Trash2 className="h-4 w-4 text-muted-foreground" /></Button>
                    </div>
                  ))}
                  {completedTasks.length === 0 && <p className="text-sm text-muted-foreground p-2">No tasks completed yet.</p>}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="reminders" className="flex-1 overflow-auto mt-4">
             <Card>
              <CardHeader>
                <CardTitle>Set a Reminder</CardTitle>
                 <div className="flex flex-col md:flex-row gap-2 pt-2">
                  <Input value={newReminderText} onChange={(e) => setNewReminderText(e.target.value)} placeholder="What to remind you about?" />
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full md:w-auto justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {newReminderDate ? format(newReminderDate, 'PPP') : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar mode="single" selected={newReminderDate} onSelect={setNewReminderDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                  <Button onClick={handleAddReminder}><Bell className="mr-2 h-4 w-4" /> Set Reminder</Button>
                </div>
              </CardHeader>
              <CardContent>
                <h3 className="font-semibold text-lg mb-2">Upcoming Reminders</h3>
                 <ScrollArea className="h-72">
                  <div className="space-y-2">
                    {reminders.filter(r => !r.completed).map(reminder => (
                      <div key={reminder.id} className="flex items-center gap-2 rounded-md p-3 border">
                        <Bell className="h-5 w-5 text-primary" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{reminder.text}</p>
                          <p className="text-xs text-muted-foreground">{format(parseISO(reminder.remindAt), "MMMM d, yyyy 'at' h:mm a")}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteReminder(reminder.id)}><X className="h-4 w-4 text-muted-foreground" /></Button>
                      </div>
                    ))}
                    {reminders.filter(r => !r.completed).length === 0 && <p className="text-sm text-muted-foreground p-2 text-center">No upcoming reminders.</p>}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
